from django import forms
from accounts.models import User


class UserProfileForm(forms.Form):
    class meta:
        model = User
        fields = ['user', 'image', 'phone', 'location', 'facebook_url', 'twitter_url', 'linked_url', 'youtube_url', 'website_url']
