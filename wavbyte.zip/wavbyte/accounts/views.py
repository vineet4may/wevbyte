from __future__ import unicode_literals
import json
import os
from datetime import datetime, timedelta
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import AuthenticationForm, PasswordResetForm, SetPasswordForm
from django.contrib.auth.hashers import make_password
from django.contrib.auth import login, authenticate
from django.contrib.auth.password_validation import get_default_password_validators
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.core.exceptions import ValidationError
from django.core.mail import EmailMessage
from django.db.models import Q
from django.template.loader import render_to_string
from django.template.response import TemplateResponse
from django.urls import reverse
from django.http import HttpResponseRedirect
from django.http.response import HttpResponse
from django.shortcuts import render, resolve_url
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_text, force_bytes
from django.views.decorators.cache import never_cache
from django.views.decorators.csrf import csrf_protect
from django.views.decorators.debug import sensitive_post_parameters
from django.contrib.auth import (login as auth_login, logout as auth_logout, get_user_model)
from django.views.generic import ListView
from accounts.froms import UserProfileForm
from accounts.models import User, GENRE_CHOICES, Song, Categories, DownloadSong, MusicPlay, payment_decorator, Album, \
    Follow
from django.utils.translation import ugettext as _
from wavbyte import settings
from .tokens import account_activation_token
from wavbyte.settings import USER_REDIRECT_FIELD_NAME
from membership.models import Plans,Membership_transaction,Credit_used
import xml.etree.ElementTree as ET

def landing_page(request):
    return render(request, 'index.html')


def sample_page(request):
    to_date = datetime.now().date()+timedelta(days=1)
    from_date = datetime.now().date()-timedelta(days=10)
    recent_upload = Song.all_music.filter(created__range = (from_date, to_date))
    most_popular = Song.all_music.filter(play_count__gte = 5).order_by('play_count')[:10]
    album_list = Album.objects.filter(is_active = True)
    all_song = Song.all_music.all()
    return render(request, 'sounds.html', context={'objects_list':all_song, 'objects_list1':recent_upload,
                                                   'objects_list2':most_popular, 'objects_list3':album_list})


def sample_detail(request, pk):
    follow1 = None
    try:
        music_deatil = Song.all_music.get(id = pk)
    except Song.DoesNotExist:
        music_deatil = None
    if request.user.is_authenticated:
        follow = Follow.objects.filter(follower=request.user, is_fallow = True)
        if len(follow) > 0:
            follow1 = follow[0]
    most_popular = Song.all_music.filter(play_count__gte=5).order_by('play_count')[:10]
    return render(request, 'sounds-details.html', context={'objects':music_deatil, 'most_popular':most_popular, 'follow':follow1})


def album_detail(request, pk):
    try:
        album = Album.objects.filter(is_active = True).get(id = pk)
    except Album.DoesNotExist:
        album = None
    music_deatil = Song.all_music.filter(album_id=pk).order_by('id')
    most_popular = Song.all_music.filter(play_count__gte=5).order_by('play_count')[:30]
    return render(request, 'albums-details.html', context={'objects_list':music_deatil, 'most_popular':most_popular, 'objects':album})


def popular(request):
    most_popular = Song.all_music.filter(play_count__gte=5).order_by('play_count')
    return render(request, 'popular.html', context={'objects_list':most_popular})


def allsong(request):
    music_deatil = Song.all_music.all().order_by('id')
    return render(request, 'all_song.html', context={'objects_list':music_deatil})


def albumList(request):
    album = Album.objects.filter(is_active=True)
    return render(request, 'album_lists.html', context={'album_list':album})



def play(request):
    data = {'success': False}
    if request.method == 'POST':
        try:
            music_deatil = Song.all_music.get(id=request.POST.get('song_id'))
            music_deatil.play_count +=1
            music_deatil.save()
            data['success'] = True
            data['audio_file'] = (settings.MEDIA_URL+str(music_deatil.song_file))
        except Song.DoesNotExist:
            music_deatil = None
    return HttpResponse(json.dumps(data), 'Application/json')


@login_required(login_url='/')
@payment_decorator
def like_album_song(request, pk):
    try:
        music_deatil = Song.all_music.get(id=pk)
        music_deatil.like = 1
        music_deatil.save()
    except Song.DoesNotExist:
        music_deatil = None
    return HttpResponseRedirect(reverse('album_detail',args=(music_deatil.album.id,)))


@login_required(login_url='/')
@payment_decorator
def unlike_album_song(request, pk):
    try:
        music_deatil = Song.all_music.get(id=pk)
        music_deatil.like = 0
        music_deatil.save()
    except Song.DoesNotExist:
        music_deatil = None
    return HttpResponseRedirect(reverse('album_detail',args=(music_deatil.album.id,)))


@login_required(login_url='/')
@payment_decorator
def like_song(request, pk):
    try:
        music_deatil = Song.all_music.get(id=pk)
        music_deatil.like = 1
        music_deatil.save()
    except Song.DoesNotExist:
        music_deatil = None
    return HttpResponseRedirect(reverse('sample_detail',args=(music_deatil.id,)))


@login_required(login_url='/')
@payment_decorator
def unlike_song(request, pk):
    try:
        music_deatil = Song.all_music.get(id=pk)
        music_deatil.like = 0
        music_deatil.save()
    except Song.DoesNotExist:
        music_deatil = None
    return HttpResponseRedirect(reverse('sample_detail',args=(music_deatil.id,)))


@login_required(login_url='/')
@payment_decorator
def user_fallow(request, song_id, pk):
    follow = Follow()
    follow.following_id = pk
    follow.follower = request.user
    follow.save()
    return HttpResponseRedirect(reverse('sample_detail',args=(song_id,)))


@login_required(login_url='/')
@payment_decorator
def user_unfallow(request, song_id, pk):
    try:
        follow = Follow.objects.get(following_id = pk)
        follow.is_fallow = 0
        follow.save()
    except Follow.DoesNotExist:
        follow = None
    return HttpResponseRedirect(reverse('sample_detail',args=(song_id,)))


def searchBar(request):
    song_list = []
    data = {'success': False}
    if request.method == 'GET':
        q = request.GET.get('search')
        song = Song.all_music.filter(Q(title__icontains = q) | Q(artist__icontains = q) | Q(album__name__icontains = q))
        for s in song:
            if s.album:
                song_list.append({'title':s.title+' '+s.artist+' '+s.album.name, 'id':s.id})
            else:
                song_list.append({'title': s.title + ' ' + s.artist, 'id': s.id})
        data['success'] = True
        data['song_list'] = (song_list)
    return HttpResponse(json.dumps(data), 'Application/json')


def search_song(request):
    q = str(request.GET.get('q')).split()
    song_list = Song.all_music.filter(Q(title__icontains = q[0]) | Q(artist__icontains = q[1]) | Q(album__name__icontains = q[2]))
    return render(request, 'pages/search.html', context={'objects_list': song_list,'q':request.GET.get('q')})


@login_required(login_url='/')
@payment_decorator
def wallet(request):
    total_upload = Song.all_music.filter(user__username = request.user).count()
    total_download = DownloadSong.download_song.filter(user__username = request.user).count()
    return render(request, 'pages/wallet.html', context={'user_upload':total_upload, 'user_download':total_download,'total_credit' : request.user.credits})


class UploadedSong(ListView):
    model = Song
    template_name = 'songs/uploaded_song.html'

    def get_queryset(self):
        return Song.all_music.filter(user = self.request.user)


class DownloadSongList(ListView):
    model = DownloadSong
    template_name = 'songs/download_song.html'

    def get_queryset(self):
        return DownloadSong.download_song.filter(user = self.request.user)

def upload_download_process_handler(request,handler_type):
    before_credits = User.objects.only('credits').get(id=request.user.id).credits
    print('before credits-->',before_credits)
    after_credits = before_credits-1
    print('after_credits-->',after_credits)
    if handler_type =='download':
        download_id = DownloadSong.download_song.filter(user_id=request.user.id).last().id
        upload_id = None
        print('downloaded_id-->',download_id)
    else:
        upload_id = Song.all_music.filter(user_id=request.user.id).last().id
        download_id = None
        print('uploaded_id-->',upload_id)

    update_credit_used = Credit_used.objects.create(user_id = request.user.id, before_credits = before_credits, credits = int(1), after_credits = after_credits, download_id = download_id, upload_id = upload_id)  
    print('credit used table status -->',update_credit_used)
    if update_credit_used:
        update_after_credits = User.objects.filter(id=request.user.id).update(credits = int(after_credits))
        print('update_after_credits -->',update_after_credits)


def download_in_wallet(request):
    data = {'success': False}
    if request.method == 'POST':
        if request.user.is_authenticated:
            try:
                music_id = Song.all_music.get(id=request.POST.get('song_id'))
                try:
                    download_song = DownloadSong.download_song.get(song=music_id)
                except DownloadSong.DoesNotExist:
                    download_song = DownloadSong(song=music_id, user_id=request.user.id)
                    download_song.save()
                    upload_download_process_handler(request,'download')

                data['success'] = True
                data['status'] = 'Song save successfully in wallet. see your downloaded song <a href="/wallet">here</a>'
            except Song.DoesNotExist:
                data['success'] = False
                data['status'] = 'Something wrong '
        else:
            data['success'] = False
            data['status'] = 'You are not login at. Please login for song downloading <a href="/">Login</a>'
    else:
        data['success'] = False
        data['status'] = 'Get method not allow'
    return HttpResponse(json.dumps(data), 'Application/json')


@login_required(login_url='/')
@payment_decorator
def download(request):
    data = {'success': False}
    if request.method == 'POST':
        try:
            music_deatil = Song.all_music.get(id=request.POST.get('download_id'))
            try:
                m = open(os.path.join(settings.MEDIA_ROOT, str(music_deatil.song_file)), 'rb')
                f = open(os.path.join(settings.FILE_DOWNLOAD_DIR, str(music_deatil.title)), 'wb')
            except Exception as e:
                data['success'] = False
                data['status'] = 'error1'
            else:
                f.write(m.read())
                m.close()
                f.close()
                data['success'] = True
                data['status'] = 'Successful'
        except Song.DoesNotExist:
            data['success'] = False
            data['status'] = 'error2'
    else:
        data['success'] = False
        data['status'] = 'Get method not allow'
    return HttpResponse(json.dumps(data), 'Application/json')


@login_required(login_url='/')
@payment_decorator
def upload_type(request):
    if request.method == 'POST':
        category_id = request.POST.get('category')
        return HttpResponseRedirect('/upload/done/%s'%category_id)
    category = Categories.all_cate.all()
    return render(request, 'upload-type.html', context={'objects_list':category})


@login_required(login_url='/')
def add_album(request):
    if request.method == "POST":
        album = Album()
        album.name = request.POST.get('album_name')
        album.save()
        return HttpResponseRedirect('/upload/type')
    return render(request, 'upload_browse.html')


@login_required(login_url='/')
@payment_decorator
def upload_done(request, pk):
    album_list = Album.objects.all()
    try:
        category_type = Categories.all_cate.get(id = pk)
    except Categories.DoesNotExist:
        category_type = None
    if request.method == 'POST':
        up_music = Song()
        up_music.user = request.user
        up_music.title = request.POST.get('title')
        up_music.genre = request.POST.get('genre')
        up_music.catagory = category_type
        up_music.album_id = request.POST.get('album')
        up_music.cover_image = request.FILES['music_img']
        up_music.song_file = request.FILES['music_file']
        up_music.tags = request.POST.get('tags')
        up_music.description = request.POST.get('description')
        up_music.availability = int(request.POST.get('availablity'))
        up_music.artist = request.POST.get('artist')
        up_music.composer = request.POST.get('composer')
        up_music.album_title = request.POST.get('albume_title')
        up_music.producer = request.POST.get('producer')
        up_music.featuring = request.POST.get('featuring')
        up_music.instrument = request.POST.get('instrument')
        up_music.publisher = request.POST.get('publisher')
        up_music.release_title = request.POST.get('release_title')
        up_music.release_date = request.POST.get('release_date')
        up_music.record_lable = request.POST.get('record_lable')
        up_music.save()
        upload_download_process_handler(request,'upload')
        
    c = {'genre': GENRE_CHOICES, 'album_list':album_list, 'song_file':request.FILES, 'song_type':request.POST.get('song_type')}
    return render(request, 'upload-finished.html', context=c)


@login_required(login_url='/')
def dashboard_page(request):
    try:
        user_p = User.objects.get(username = request.user)
    except User.DoesNotExist:
        user_p = None
    c = {'profile': user_p}
    return render(request, 'user_page.html', context=c)



@login_required(login_url='/')
def profile_page(request):
    try:
        user_p = User.objects.get(username = request.user)
        count = profilePercent(user_p) * 10
    except User.DoesNotExist:
        user_p = None
    try:
        follower = Follow.objects.filter(follower = request.user.id)
    except Follow.DoesNotExist:
        follower = None
    c = {'profile': user_p, 'genre': GENRE_CHOICES, 'percent': count, 'followe_list':follower}
    return render(request, 'pages/my-profile.html', context=c)


@login_required(login_url='/')
def update_profile(request):
    data = {'success': False}
    if request.method == "POST":
        try:
            user_p = User.objects.get(username = request.user)
            user_p.first_name = request.POST.get('first_name', '')
            user_p.last_name = request.POST.get('last_name', '')
            user_p.phone = request.POST.get('phone', '')
            user_p.genre = request.POST.get('genre', '')
            user_p.gender = request.POST.get('gender', '')
            user_p.location = request.POST.get('location', '')
            user_p.facebook_url = request.POST.get('facebook_url', '')
            user_p.twitter_url = request.POST.get('twitter_url', '')
            user_p.linked_url = request.POST.get('linked_url', '')
            user_p.youtube_url = request.POST.get('youtube_url', '')
            user_p.website_url = request.POST.get('website', '')
            user_p.bio = request.POST.get('user_bio', '')
            user_p.save()
            data['success'] = True
            data['status'] = 'Profile Update Successfully.'
            data['redirect_url'] = '/profile'
        except User.DoesNotExist:
            data['success'] = False
            data['status'] = 'User is Not found'
    else:
        data['success'] = False
        data['status'] = 'Get method not allow'
    return HttpResponse(json.dumps(data), 'Application/json')


@login_required(login_url='/')
def update_image(request):
    data = {'success': False}
    if request.method == 'POST':
        form = UserProfileForm(request.POST, request.FILES)
        if form.is_valid():
            try:
                user_p = User.objects.get(username=request.user)
                user_p.image = request.FILES['image']
                user_p.save()
                data['success'] = True
                data['status'] = 'Success'
                data['redirect_url'] = '/profile'
            except User.DoesNotExist:
                data['success'] = False
                data['status'] = 'error'
        else:
            data['success'] = False
            data['status'] = 'Invalid from'
    else:
        form = UserProfileForm()
        data['success'] = False
        data['status'] = 'Get method not allow'
    return HttpResponse(json.dumps(data), 'Application/json')


@sensitive_post_parameters()
@csrf_protect
@never_cache
def user_login(request, redirect_field_name=USER_REDIRECT_FIELD_NAME, authentication_form=AuthenticationForm):
    """
    Displays the login form and handles the login action.
    """
    redirect_to = request.POST.get(redirect_field_name, request.GET.get(redirect_field_name, USER_REDIRECT_FIELD_NAME))

    data = {'success': False}
    if request.method == "POST":
        form = authentication_form(request, data=request.POST)
        if form.is_valid():
            auth_login(request, form.get_user())
            try:
                user = User.objects.filter(is_payment = True).get(username = request.user)
                data['redirect_url'] = redirect_to
            except User.DoesNotExist:
                data['redirect_url'] = '/membership'
            data['success'] = True
            data['status'] = 'Login successful, thank you!'
        else:
            data['success'] = False
            data['status'] = 'Please enter the correct username and password. Note that both fields may be case-sensitive. '
    else:
        data['success'] = False
        data['status'] = 'Get method not allow'
    return HttpResponse(json.dumps(data), 'Application/json')


def user_signup(request):
    data = {'success': False}
    username = ' '.join(request.POST.get('username').split())
    user_first_name = request.POST.get('user_first_name')
    user_last_name = request.POST.get('user_last_name')
    user_email = ' '.join(request.POST.get('user_email').split())
    password = request.POST.get('user_password')
    confirm_password = request.POST.get('user_confirm_password')
    if password != confirm_password:
        data['status'] = "Passwords do not match"
        data['success'] = False
    else:
        try:
            user = User.objects.get(username = username)
            data['status'] = "username already exits."
            data['success'] = False
        except User.DoesNotExist:
            try:
                user = User.objects.get(email = user_email)
                data['status'] = "This email already exits."
                data['success'] = False
            except User.DoesNotExist:
                password = make_password(password)
                user = User(email=user_email, username=username, password=password, first_name=user_first_name, last_name=user_last_name)
                user.is_active = False
                user.save()
                current_site = get_current_site(request)
                mail_subject = 'Activate your Wavbyte account.'
                message = render_to_string('accounts/acc_active_email.html', {
                    'user': user,
                    'domain': current_site.domain,
                    'uid':urlsafe_base64_encode(force_bytes(user.pk)).decode(),
                    'token':account_activation_token.make_token(user),
                })
                to_email = user_email
                email = EmailMessage(
                    mail_subject, message, to=[to_email]
                )
                email.send()
                data['status'] = "Please confirm your email address to complete the registration."
                data['success'] = True
    return HttpResponse(json.dumps(data), 'Application/json')

def user_logout(request):
    auth_logout(request)
    messages.success(request, 'You have been logged out!.')
    return HttpResponseRedirect(reverse('landing_page'))


def validate_password(password, user=None, password_validators=None):
    """
    Validate whether the password meets all validator requirements.

    If the password is valid, return ``None``.
    If the password is invalid, raise ValidationError with all error messages.
    """
    errors = []
    if password_validators is None:
        password_validators = get_default_password_validators()
    for validator in password_validators:
        try:
            validator.validate(password, user)
        except ValidationError as error:
            errors.append(error)
    if errors:
        return ValidationError(errors)


@login_required(login_url='/')
def change_password(request):
    data = {'success': False}
    if request.method == 'POST':
        if not request.POST.get('old_password'):
            data['success'] = False
            data['status'] = 'Provide the old password'
        if not request.POST.get('new_password1'):
            data['success'] = False
            data['status'] = 'Provide a valid new password.'
        if request.POST.get('new_password1') != request.POST.get('new_password2'):
            data['success'] = False
            data['status'] = 'password_mismatch.'
        else:
            user = authenticate(username=request.user.username, password=request.POST.get('old_password'))
            if user is not None:
                v_pass = validate_password(request.POST.get('new_password1'))
                if v_pass != None:
                    data['success'] = False
                    data['status'] = str(v_pass)
                else:
                    user.password = make_password(request.POST.get('new_password1'))
                    user.save()
                    auth_logout(request)
                    data['success'] = True
                    data['status'] = 'Password change successfully.'
                    data['redirect_url'] = '/'
            else:
                data['success'] = False
                data['status'] = 'Incorrect old password.'
    else:
        data['success'] = False
        data['status'] = 'Get method not allow'
    return HttpResponse(json.dumps(data), 'Application/json')


def activate(request, uidb64, token):
    data = {'success': False}
    try:
        uid = force_text(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except User.DoesNotExist:
        user = None
    if user is not None and account_activation_token.check_token(user, token):
        user.is_active = True
        user.save()
        # login(request, user)
        c = {'message': 'Thank you for your email confirmation. Now you can login your account.', 'fontcolor':'alert alert-success'}
    else:
        c = {'message':'Activation link is invalid!', 'fontcolor':'alert alert-danger'}

    return render(request, 'accounts/acc_activation_response.html', context=c)

def profilePercent(user_p):
    percent = 0
    if (user_p.first_name != "" and user_p.first_name is not None):
        percent = percent + 1
    if (user_p.last_name != "" and user_p.last_name is not None):
        percent = percent + 1
    if (user_p.location != "" and user_p.location is not None):
        percent = percent + 1
    if (user_p.phone != "" and user_p.phone is not None):
        percent = percent + 1
    if (user_p.genre != '0'):
        percent = percent + 1
    if (user_p.website_url != "" and user_p.website_url is not None):
        percent = percent + 1
    if (user_p.bio != "" and user_p.bio is not None):
        percent = percent + 1
    if (user_p.youtube_url != "" and user_p.youtube_url is not None):
        percent = percent + 1
    if (user_p.twitter_url != "" and user_p.twitter_url is not None):
        percent = percent + 1
    if (user_p.facebook_url != "" and user_p.facebook_url is not None):
        percent = percent + 1
    return percent


def password_reset(request, is_admin_site=False,
                   template_name='accounts/password_reset_form.html',
                   email_template_name='accounts/password_reset_email.html',
                   subject_template_name='accounts/password_reset_subject.txt',
                   password_reset_form=PasswordResetForm, token_generator=default_token_generator,
                   post_reset_redirect=None, from_email=None, current_app=None,
                   extra_context=None, html_email_template_name=None):

    if post_reset_redirect is None:
        post_reset_redirect = reverse('password_reset_done')
    else:
        post_reset_redirect = resolve_url(post_reset_redirect)
    if request.method == "POST":
        form = password_reset_form(request.POST)
        if form.is_valid():
            opts = { 'use_https': request.is_secure(),
                     'token_generator': token_generator,
                     'from_email': from_email,
                     'email_template_name': email_template_name,
                     'subject_template_name': subject_template_name,
                     'request': request,
                     'html_email_template_name': html_email_template_name,
                     }
            if is_admin_site:
                opts = dict(opts, domain_override=request.get_host())
            form.save(**opts)
            return HttpResponseRedirect(post_reset_redirect)
    else:
        form = password_reset_form()
    context = { 'form': form,
                    'title': _('Password reset'),
                    }
    if extra_context is not None:
        context.update(extra_context)
    return TemplateResponse(request, template_name, context)


def password_reset_done(request,
                        template_name='accounts/password_reset_done.html',
                        current_app=None, extra_context=None):
    context = {
        'title': _('Password reset successful'),
    }
    if extra_context is not None:
        context.update(extra_context)
    return TemplateResponse(request, template_name, context)


@sensitive_post_parameters()
@never_cache
def password_reset_confirm(request, uidb64=None, token=None,
                           template_name='accounts/password_reset_confirm.html',
                           token_generator=default_token_generator, set_password_form=SetPasswordForm,
                           post_reset_redirect=None, current_app=None, extra_context=None):
    """ View that checks the hash in a password reset link and presents a form for entering a new password. """
    UserModel = get_user_model()

    assert uidb64 is not None and token is not None # checked by URLconf
    if post_reset_redirect is None:
        post_reset_redirect = reverse('password_reset_complete')
    else:
        post_reset_redirect = resolve_url(post_reset_redirect)
    try:
        uid = urlsafe_base64_decode(uidb64)
        user = UserModel._default_manager.get(pk=uid)
    except (TypeError, ValueError, OverflowError, UserModel.DoesNotExist):
        user = None

    if user is not None and token_generator.check_token(user, token):
        validlink = True
        title = _('Enter new password')
        if request.method == 'POST':
            form = set_password_form(user, request.POST)
            if form.is_valid():
                form.save()
                return HttpResponseRedirect(post_reset_redirect)
        else:
            form = set_password_form(user)
    else:
        validlink = False
        form = None
        title = _('Password reset unsuccessful')
    context = { 'form': form, 'title': title, 'validlink': validlink, }
    if extra_context is not None:
        context.update(extra_context)
    return TemplateResponse(request, template_name, context)


def password_reset_complete(request,
                            template_name='accounts/password_reset_complete.html',
                            current_app=None, extra_context=None):
    context = {
        'login_url': resolve_url(settings.LOGIN_URL),
        'title': _('Password reset complete'),
    }
    if extra_context is not None:
        context.update(extra_context)
    return TemplateResponse(request, template_name, context)

