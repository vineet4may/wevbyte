import datetime
import math
import os
import pygame

from PIL import Image
from django.contrib.auth.models import AbstractUser, Group
from django.core.validators import FileExtensionValidator
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.http import HttpResponseRedirect
from django.utils.translation import gettext as _


from tinytag import TinyTag
from wavbyte import settings


class MusicPlay(object):

    def __init__(self, music_f = None):
        pygame.mixer.init(44100, -16, 2, 2048)
        self.music_f = music_f

    def play(self):
        pygame.mixer.music.load(self.music_f)
        pygame.mixer.music.play()


    def song_stop(self):
        pygame.mixer.music.stop()

    def pause(self):
        pygame.mixer.music.pause()

    def resume(self):
        pygame.mixer.music.unpause()

# payment decorator
def payment_decorator(org_func):
    def check_payment(request, *args, **kwargs):
        try:
            user = User.objects.filter(is_payment=True).get(username=request.user)
            return org_func(request, *args, **kwargs)
        except User.DoesNotExist:
            user = None
            return HttpResponseRedirect('/membership')
    return check_payment


def user_upload_to(instance, filename):
    return 'users/{}.{}'.format(instance.username, filename.split('.')[-1])


def music_upload_to(instance, filename):
    return 'music/song/{}.{}'.format(instance.user.username, filename.split('.')[-1])


def music_img_upload_to(instance, filename):
    return 'music/img/{}.{}'.format(instance.user.username, filename.split('.')[-1])


def album_img_upload_to(instance, filename):
    return 'music/album/{}.{}'.format(instance.name, filename.split('.')[-1])


def catagories_img_upload_to(instance, filename):
    return 'catagories_img/{}.{}'.format(instance.name, filename.split('.')[-1])


GENDER_CHOICES = (
        ('M', 'Male'),
        ('F', 'Female'),
    )


GENRE_CHOICES = (
        ('P', 'Pop'),
        ('A', 'Artist'),
    )


class User(AbstractUser):
    image = models.ImageField('Profile picture', upload_to=user_upload_to, null = True, blank = True, default='default.png')
    phone = models.CharField('Phone' ,max_length = 15 ,blank = True)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, blank=True)
    genre = models.CharField(max_length=1, choices=GENRE_CHOICES, blank=True)
    location = models.CharField(_('Location'), max_length = 100, null = True, blank = True)
    facebook_url = models.URLField('Facebook in URL', default = "", blank = True)
    twitter_url = models.URLField('Twitter in URL', default = "", blank = True)
    linked_url = models.URLField('Linked in URL', default = "", blank = True)
    youtube_url = models.URLField('YouTube in URL', default = "", blank = True)
    website_url = models.URLField('Website URL', default = "", blank = True)
    bio = models.TextField('Short Biography')
    is_payment = models.BooleanField(default=False)
    credits = models.IntegerField(blank=True, null=True)
    credit_expire = models.DateTimeField(null=True, blank=True)
    fallow = models.BooleanField(default=False)


    def get_full_name(self):
        '''
        Returns the first_name plus the last_name, with a space in between.
        '''
        full_name = '%s %s' % (self.first_name, self.last_name)
        return full_name.strip()


    def save(self, *args, **kwargs):
        super(User, self).save(*args, **kwargs)
        if self.image:
            image = Image.open(self.image)
            (width, height) = image.size
            size = (200, 200)
            image = image.resize(size, Image.ANTIALIAS)
            image.save(self.image.path)


class Follow(models.Model):
    following = models.ForeignKey(User, related_name="who_follows", on_delete=models.CASCADE)
    follower = models.ForeignKey(User, related_name="who_is_followed", on_delete=models.CASCADE)
    is_fallow = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    follow_time = models.DateTimeField(auto_now=True)


class Categories(models.Model):
    name = models.CharField(max_length=255)
    c_img = models.ImageField('Category Image', upload_to=catagories_img_upload_to)

    all_cate = models.Manager()

    def save(self, *args, **kwargs):
        super(Categories, self).save(*args, **kwargs)
        if self.c_img:
            image = Image.open(self.c_img)
            (width, height) = image.size
            size = (124, 82)
            image = image.resize(size, Image.ANTIALIAS)
            image.save(self.c_img.path)


    def __str__(self):
        return self.name

    def category_by_music(self):
        return self.song_category.all()


class Album(models.Model):
    name = models.CharField('Album name', max_length=100)
    cover_image = models.ImageField('Cover Image', upload_to=album_img_upload_to, default='album-ic.png')
    created = models.DateTimeField("Created", auto_now_add=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class Song(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    catagory = models.ForeignKey(Categories, on_delete=models.CASCADE, related_name='song_category')
    album = models.ForeignKey(Album, on_delete=models.CASCADE, related_name='album_list', null=True, blank=True)
    title = models.CharField('Title' ,max_length=100, null=True, blank=True)
    genre = models.CharField('Genre',max_length=1, choices=GENRE_CHOICES, blank=True)
    cover_image = models.ImageField('Cover Image',upload_to=music_img_upload_to, default='music-ic.png')
    song_file = models.FileField(upload_to=music_upload_to, validators=[FileExtensionValidator(allowed_extensions=['wav', 'midi'])])
    tags = models.CharField(max_length=255, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    availability = models.IntegerField(default=0, help_text='{0: public, 1:public}') # {0: public, 1:public}
    artist = models.CharField('Artist' ,max_length=100, null=True, blank=True, default='Unknow Artist')
    composer = models.CharField('Composer',max_length=100, null=True, blank=True)
    album_title = models.CharField('Album name' ,max_length=50, null=True, blank=True)
    track_number = models.SmallIntegerField('Track number', blank=True, null=True)
    track_total = models.SmallIntegerField('Total track count', blank=True, null=True)
    disc_number = models.SmallIntegerField(_('Disc number'), blank=True, null=True)
    disc_total = models.SmallIntegerField(_('Total disc count'), blank=True, null=True)
    producer = models.CharField('Producer',max_length=100, null=True, blank=True)
    featuring = models.CharField(max_length=100, null=True, blank=True)
    instrument = models.CharField('Instrument',max_length=100, null=True, blank=True)
    publisher = models.CharField('Publisher', max_length=100, blank=True)
    release_title = models.CharField(max_length=100, null=True, blank=True)
    release_date = models.DateTimeField(default=datetime.datetime.now)
    record_lable = models.CharField(max_length=100, null=True, blank=True)
    created = models.DateTimeField("Created", auto_now_add=True)
    play_count = models.IntegerField('Play count', default=0)
    like = models.BooleanField(default=False)

    all_music = models.Manager()





    class Meta:
        verbose_name = 'Upload'


    def save(self, *args, **kwargs):
        super(Song, self).save(*args, **kwargs)
        if self.cover_image:
            image = Image.open(self.cover_image)
            (width, height) = image.size
            size = (200, 200)
            image = image.resize(size, Image.ANTIALIAS)
            image.save(self.cover_image.path)


    def __str__(self):
        return "%s"%(self.title)


    def music_info(self):
        return self.song_info.get()


class SongInfo(models.Model):
    song = models.ForeignKey(Song, on_delete=models.CASCADE, verbose_name='Music Title', related_name='song_info')
    bpm = models.CharField(max_length=255, null=True, blank=True)
    file_size = models.CharField('File size' ,max_length=255, null=True, blank=True)
    duration = models.CharField('Song duration in seconds',max_length=255, null=True, blank=True)
    samplerate = models.CharField(max_length=255, null=True, blank=True)
    created = models.DateTimeField("Created", default=datetime.datetime.now)

    class Meta:
        verbose_name = 'Song Details'

    def __str__(self):
        return "%s"%(self.song)

    def convert_size(self):
        size_bytes = int(self.file_size)
        if size_bytes == 0:
            return "0B"
        size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
        i = int(math.floor(math.log(size_bytes, 1024)))
        p = math.pow(1024, i)
        s = round(size_bytes / p, 2)
        return "%s %s" % (s, size_name[i])

    def song_time(self):
        m, s = divmod(float(self.duration), 60)
        if m == 0:
            return "%02d Sec" % (s)
        else:
            return "%02d Min. %02d Sec" % (m, s)


@receiver(post_save, sender=Song)
def save_bpm(sender, instance, **kwargs):
    try:
        music_inf = SongInfo.objects.get(song = instance)
    except SongInfo.DoesNotExist:
        music_inf = SongInfo()
        tag = TinyTag.get(os.path.join(settings.MEDIA_ROOT, str(instance.song_file)), image=True)
        music_inf.song = instance
        music_inf.bpm = tag.bitrate
        music_inf.file_size = tag.filesize
        music_inf.duration = tag.duration
        music_inf.samplerate = tag.samplerate
        music_inf.save()




class DownloadSong(models.Model):
    song = models.ForeignKey(Song, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    created = models.DateTimeField("Created", default=datetime.datetime.now)

    download_song = models.Manager()

    class Meta:
        verbose_name = 'Download'