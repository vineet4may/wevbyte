from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from accounts.models import User, Song, Categories, SongInfo, DownloadSong, Album, Follow


class UserProfileAdmin(BaseUserAdmin):
    list_display = ['username', 'email', 'genre', 'gender', 'phone', 'location', 'image' ]
    list_editable = ['genre', 'gender']
    search_fields = ('username',)
    fieldsets = (
        ('User Detail', {
            'fields': ('first_name', 'last_name', 'email',('is_superuser', 'is_staff', 'is_active') )
        }),
        ('Username and Password', {
            'classes': ('collapse',),
            'fields': ('username', 'password')
        }),
        ('Add Personal Detail', {
            'classes': ('collapse',),
            'fields': (('phone', 'location',), ('genre', 'gender'),( 'image', 'bio' ))
        }),
        ('Payment', {
            # 'classes': ('collapse',),
            'fields': ('credits', 'credit_expire', 'is_payment'),
        }),
        ('Add Social Links', {
            'classes': ('collapse',),
            'fields': ('facebook_url', 'twitter_url', 'linked_url', 'youtube_url', 'website_url'),
        }),
    )


class SongAdmin(admin.ModelAdmin):
    list_display = ['user', 'title', 'genre', 'catagory', 'artist', 'album', 'tags', 'availability_song', 'release_date']
    readonly_fields = ['availability_song']
    # list_editable = ['catagory']
    fieldsets = (
        ('Basic Info', {
            'fields': (('user'),('title', 'tags'), ('genre', 'availability_song', 'catagory'), ('description'))
        }),
        ('song', {
            'classes': ('collapse',),
            'fields': (('cover_image', 'song_file'),)
        }),
        ('Meta Data', {
            'classes': ('collapse',),
            'fields': (('artist', 'composer'), ('album', 'producer'), ('featuring','instrument',))
        }),
        ('Release', {
            'classes': ('collapse',),
            'fields': ('publisher', 'release_title', 'record_lable')
        }),
        ('Dates', {
            # 'classes': ('collapse',),
            'fields': (('release_date', 'play_count'),),
        }),
    )

    def availability_song(self, obj):
        if obj.availability == 0:
            return "Public"
        if obj.availability == 1:
            return "Private"

class CategoriesAdmin(admin.ModelAdmin):
    list_display = ['name', 'c_img']


class SongInfoAdmin(admin.ModelAdmin):
    list_display = ['song', 'bpm', 'file_size', 'duration', 'samplerate']
    # readonly_fields = ['song']


class DownloadSongAdmin(admin.ModelAdmin):
    list_display = ['song', 'user', 'created']
    readonly_fields = ['song']


class AlbumAdmin(admin.ModelAdmin):
    list_display = ['name', 'cover_image']



class FollowAdmin(admin.ModelAdmin):
    list_display = ['following', 'follower', 'is_fallow', 'follow_time', 'created']



admin.site.register(User, UserProfileAdmin)
admin.site.register(Song, SongAdmin)
admin.site.register(Categories, CategoriesAdmin)
admin.site.register(SongInfo, SongInfoAdmin)
admin.site.register(DownloadSong, DownloadSongAdmin)
admin.site.register(Album, AlbumAdmin)
admin.site.register(Follow, FollowAdmin)