$(document).ready(function() {
     toggleFun();
    $('#id_check').hide();
    $('#id_search').hide();

// upload page previous and next button code
    $(document).ready(function(){
            $('.btnNext').click(function(){
              $('.nav-link.active').parent().next('li').find('a').trigger('click');
            });

            $('.btnPrevious').click(function(){
              $('.nav-link.active').parent().prev('li').find('a').trigger('click');
            });
        });

// ajax login post request
    $("#id_login_form").submit(function(event) {
       event.preventDefault();
       $.ajax({ data: $(this).serialize(),
                type: $(this).attr('method'),
                url: $(this).attr('action'),
                success: function(data) {
                     if(data.success == true) {
                         $("#_id_login_response").html("<div class='alert alert-success'>"+data.status+"</div>");
                         $("#id_login_form")[0].reset();
                         window.location.href = data.redirect_url;
                     }
                     else{
                         $("#_id_login_response").html("<div class='alert alert-danger'>"+data.status+"</div>");
                     }
                },
       });
   });


//   ajax signup post request
   $("#id_signup_from").submit(function(event) {
      event.preventDefault();
      $.ajax({ data: $(this).serialize(),
               type: $(this).attr('method'),
               url: $(this).attr('action'),
               success: function(data) {
                    if(data.success == true) {
                        $("#_id_signup_response").html("<div class='alert alert-success'>"+data.status+"</div>");
                        $("#id_signup_from")[0].reset();
                    }
                    else{
                        $("#_id_signup_response").html("<div class='alert alert-danger'>"+data.status+"</div>");
                    }
               },
      });
  });

// update user profile
  $("#id_profile_form").submit(function(event) {
      event.preventDefault();
      $.ajax({ data: $(this).serialize(),
               type: $(this).attr('method'),
               url: $(this).attr('action'),
               success: function(data) {
                    if(data.success == true) {
                        $("#id_profile_status").html("<div class='alert alert-success'>"+data.status+"</div>");
                        window.location.href = data.redirect_url;
                    }
                    else{
                        $("#id_profile_status").html("<div class='alert alert-danger'>"+data.status+"</div>");
                    }
               },
      });
  });


//update user password
  $("#id_change_password_form").submit(function(event) {
      event.preventDefault();
      $.ajax({ data: $(this).serialize(),
               type: $(this).attr('method'),
               url: $(this).attr('action'),
               success: function(data) {
                    if(data.success == true) {
                        $("#id_profile_status").html("<div class='alert alert-success'>"+data.status+"</div>");
                        window.location.href = data.redirect_url;
                    }
                    else{
                        $("#id_profile_status").html("<div class='alert alert-danger'>"+data.status+"</div>");
                    }
               },
      });
  });

//  file upload on profile
    $("#id_update_image").change(function(event) {
        var data = new FormData($('form').get(0));
        event.preventDefault();
        $.ajax({ data: data,
               type: $(this).attr('method'),
               url: $(this).attr('action'),
               cache: false,
               processData: false,
               contentType: false,
               success: function(data) {
                    if(data.success == true) {
                        $("#id_profile_status").html("<div class='alert alert-success'>"+data.status+"</div>");
                        window.location.href = data.redirect_url;
                    }
                    else{
                        $("#id_profile_status").html("<div class='alert alert-danger'>"+data.status+"</div>");
                    }
               },
        });
    });

//  searchBar
    $('#searchBar').on('input',function(e){
        var search_len = $('#searchBar').val().trim();
        if (search_len.length > 0){
            $('#id_search').html('');
              $.ajax({ data: {'search':$('#searchBar').val()},
                   type: "GET",
                   url: '/searchBar',
                   success: function(data) {
                        if(data.success == true) {
                            l = data.song_list.length
                            for(i=0; i<l; i++){
                                var newOption = $('<form action="/search" method="get" autocomplete="off"><input type="hidden" name="q" value="'+data.song_list[i]['title']+'"><input style="text-align: left;" class="form-control"  type="submit" value="'+data.song_list[i]['title']+'"></from>');
                                $('#id_search').append(newOption);
                                $('#id_search').show();
                            }
                        }
                        else{
                           $('#searchBarResult').val('Song not found');
                        }
                   },
              });
          }
          else{
          $('#id_search').hide();
          }
    });

//    progress slide
    $('#id_music_file').change(function(){
        var value = $('#id_music_file').val();
        if ( value.length > 0 ){
            $('#id_progress').css({"width": "100%"});
            $('#id_check').show();
        }
    });




// start sound page code
    $('#owl-slide').owlCarousel({
            loop: true,
            margin:0,
            responsiveClass: true,
            responsive: {
              0: {
                items: 1,
                nav: true,
                dots: false,
                navigationText : ["",""],
              },
              600: {
                items: 2,
                nav: true,
                dots: false,
                navigationText : ["",""],
              },
      980: {
                items: 3,
                nav: true,
                dots: false,
                navigationText : ["",""],
              },
              1170: {
                items: 4,
                nav: true,
                dots: false,
                navigationText : ["",""],

                loop: true
              }
            }
          });

    $('#recent-releases-pack').owlCarousel({
                    loop: true,
                    margin:10,
                    responsiveClass: true,
                    responsive: {
                      0: {
                        items: 2,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      600: {
                        items: 3,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      980: {
                        items: 4,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      1170: {
                        items: 6,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],

                        loop: true
                      }
                    }
                  });

    $('#featured-pack').owlCarousel({
                    loop: true,
                    margin:10,
                    responsiveClass: true,
                    responsive: {
                      0: {
                        items: 2,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      600: {
                        items: 3,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
              980: {
                        items: 4,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      1170: {
                        items: 6,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],

                        loop: true
                      }
                    }
                  });


    $('#artist-pack').owlCarousel({
                    loop: true,
                    margin:10,
                    responsiveClass: true,
                    responsive: {
                      0: {
                        items: 2,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      600: {
                        items: 3,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
              980: {
                        items: 4,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      1170: {
                        items: 6,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],

                        loop: true
                      }
                    }
                  });

    $('#missed-pack').owlCarousel({
                    loop: true,
                    margin:10,
                    responsiveClass: true,
                    responsive: {
                      0: {
                        items: 2,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      600: {
                        items: 3,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
              980: {
                        items: 4,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      1170: {
                        items: 6,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],

                        loop: true
                      }
                    }
                  });


    $('#vibe-pack').owlCarousel({
                    loop: true,
                    margin:10,
                    responsiveClass: true,
                    responsive: {
                      0: {
                        items: 2,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      600: {
                        items: 3,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
              980: {
                        items: 4,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],
                      },
                      1170: {
                        items: 6,
                        nav: true,
                        dots: false,
                        navigationText : ["",""],

                        loop: true
                      }
                    }
                  });

// end sound page code

// sound detail page
$('#most-popular-pack').owlCarousel({
        loop: true,
        margin:10,
        responsiveClass: true,
        responsive: {
          0: {
            items: 2,
            nav: true,
            dots: false,
            navigationText : ["",""],
          },
          600: {
            items: 3,
            nav: true,
            dots: false,
            navigationText : ["",""],
          },
          980: {
            items: 4,
            nav: true,
            dots: false,
            navigationText : ["",""],
          },
          1170: {
            items: 6,
            nav: true,
            dots: false,
            navigationText : ["",""],

            loop: true
          }
        }
      });

});


var toggleFun = function (type){
    if (type == 'login'){
        $('#loginTab').click();
    }else {
        $('#signTab').click();
    }
};


//play song
function play(play_id){
    $.ajax({ data: {'song_id':play_id,   csrfmiddlewaretoken: $("input[name='csrfmiddlewaretoken']").val()},
               type: "POST",
               url: '/play',
               success: function(data) {
                    if(data.success == true) {
                     $('#audio_play').attr("src",data.audio_file);
                    }
               },
      });
}


// song move to wallet
function move_to_wallet(song_id){
    $.ajax({ data: {'song_id':song_id,   csrfmiddlewaretoken: $("input[name='csrfmiddlewaretoken']").val()},
               type: "POST",
               url: '/downloadinwallet',
               success: function(data) {
                    if(data.success == true) {
                    $('#exampleModal').modal({ backdrop: 'static', keyboard: false, show: true})
                    $('#id_status').html("<div class='alert alert-success'>"+data.status+"</div>");
                    }
                    else{
                        $('#exampleModal').modal('show')
                        $('#id_status').html("<div class='alert alert-danger'>"+data.status+"</div>");
                    }
               },
      });

}

//download music file
function download(download_id){
    $.ajax({ data: {'download_id':download_id,   csrfmiddlewaretoken: $("input[name='csrfmiddlewaretoken']").val()},
               type: "POST",
               url: '/download',
               success: function(data) {
                    if(data.success == true) {
                        $('#exampleModal').modal({ backdrop: 'static', keyboard: false, show: true})
                        $('#id_status').html("<div class='alert alert-success'>"+data.status+"</div>");
                    }
                    else{
                        $('#exampleModal').modal({ backdrop: 'static', keyboard: false, show: true})
                        $('#id_status').html("<div class='alert alert-danger'>"+data.status+"</div>");
                    }
               },
      });

}

