from django.contrib import admin
from . models import Plans, Membership_transaction, Credit_used

class MembershipPlan(admin.ModelAdmin):
	list_display = ['plan_name', 'plan_amount','plan_credits', 'plan_discount', 'plan_description', 'plan_validity']



class MembershipTransactions(admin.ModelAdmin):
	list_display = ['user_id', 'transaction_id', 'previous_credits', 'provide_credits']


class CreditUsed(admin.ModelAdmin):
	list_display = ['user_id', 'before_credits', 'credits', 'after_credits', 'download_id', 'upload_id']


admin.site.register(Plans,MembershipPlan)
admin.site.register(Membership_transaction,MembershipTransactions)
admin.site.register(Credit_used, CreditUsed)
