import datetime
import os
from accounts.models import Song, DownloadSong
from PIL import Image
from django.contrib.auth.models import AbstractUser, Group
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.utils.translation import gettext as _
from paypal.standard.ipn.signals import payment_was_successful




# Create your models here.
from tinytag import TinyTag

from wavbyte import settings

class Plans(models.Model):
	plan_name = models.CharField(max_length=50,default="")
	plan_amount = models.CharField(max_length=50,default="")
	plan_credits = models.IntegerField(blank=True, null=True)
	plan_discount = models.DecimalField(max_digits=6, decimal_places=2)
	plan_description = models.TextField()
	plan_validity= models.CharField(max_length=200, default="",blank=True)
	created_at = models.DateTimeField(auto_now_add=True, blank=True)
	updated_at = models.DateTimeField(auto_now=True, blank=True)
	status = models.CharField(max_length=32,blank=True, default="")


class Membership_transaction(models.Model):
	user_id = models.IntegerField(blank=True, null=True)
	transaction_id = models.CharField(max_length=50,default="")
	previous_credits = models.IntegerField(blank=True, null=True)
	provide_credits = models.IntegerField(blank=True, null=True)
	created_at = models.DateTimeField(auto_now_add=True, blank=True)


class Credit_used(models.Model):
	user_id = models.IntegerField(blank=True, null=True)
	upload = models.ForeignKey(Song, on_delete=models.CASCADE, null=True, blank=True)
	download = models.ForeignKey(DownloadSong, on_delete=models.CASCADE, null=True, blank=True)
	before_credits = models.IntegerField(blank=True, null=True)
	credits = models.IntegerField(blank=True, null=True)
	after_credits = models.IntegerField(blank=True, null=True)
	created_at = models.DateTimeField(auto_now_add=True, blank=True)
	updated_at = models.DateTimeField(auto_now=True, blank=True)

