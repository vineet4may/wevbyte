from __future__ import unicode_literals
import json
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from django.http.response import HttpResponse
from membership.models import *
from wavbyte import settings
from django.utils.html import escape
from django.utils import timezone
from paypal.standard.forms import PayPalPaymentsForm
from paypal.standard.ipn.signals import valid_ipn_received, invalid_ipn_received
from django.views.decorators.csrf import csrf_exempt
from datetime import timedelta
from django.shortcuts import render, HttpResponseRedirect, render_to_response
from accounts.models import User, SongInfo, DownloadSong
from paypal.standard.ipn.models import PayPalIPN
import traceback
import uuid


@login_required(login_url='/')
def payment_process(request):
	try:
		subscription_plan = Plans.objects.get(id=request.POST.get('payment_plan'))
	except Plans.DoesNotExist:
		subscription_plan = None
	if request.method == "POST":
		host = request.get_host()
		paypal_dict = {
			"business": settings.PAYPAL_RECEIVER_EMAIL,
			"amount": subscription_plan.plan_amount,
			"item_name": subscription_plan.plan_name,
			"invoice": 'wavbyte'+uuid.uuid4().hex,
			"notify_url": request.build_absolute_uri(reverse('paypal-ipn')),
			"return": request.build_absolute_uri(reverse('return')),
			"cancel_return": request.build_absolute_uri(reverse('cancel')),        
			"custom": request.user.id, # Custom command to correlate to some function later (optional)
			"plan_credits":subscription_plan.plan_credits,
			"plan_discount":subscription_plan.plan_discount,
			"plan_validity":subscription_plan.plan_validity,
			"plan_description":subscription_plan.plan_description,

		}
		valid_ipn_received.connect(show_me_the_money)   
		# Create the instance.
		form = PayPalPaymentsForm(initial=paypal_dict)
		context = {"form": form, "paypal": paypal_dict}
		return render(request, "membership/payment.html", context)
	else:
		return HttpResponseRedirect(reverse('landing_page'))

def is_valid_membership(request):
    # before_credits = User.objects.only('credits').get(id=request.user.id).credits
    # after_credits = before_credits-1
    #upload_id = SongModel.all_music.filter(id=request.user.id).order_by('id')[1]
    #upload_id = SongModel.all_music.filter(user_id=request.user.id).last().id
    #upload_id = SongModel.all_music.filter(user_id=request.user.id).last().id
    #print('#####2222',upload_id)
    # download_id = DownloadSong.download_song.filter(user_id=request.user.id).last()
    # if not download_id:
    #     download_id = 'NULL'
    # else:
    #     download_id = download_id.id
    # print('downloaded_id-->',download_id)    
    # update_after_credits = User.objects.filter(id=request.user.id).update(credits = int(after_credits))
    credits = User.objects.filter(id= request.user.id).values('credits')[0]['credits']
    expire_date = User.objects.filter(id= request.user.id).values('credit_expire')[0]['credit_expire'].timestamp()
    current_dt = timezone.now().timestamp()
    #print (timezone.now())
    time_st  = expire_date - current_dt
    if time_st <= 0:
        data = {'message' : 'Subscriptions expired !', 'status' : False}
        return HttpResponse(json.dumps( data ))
    elif credits == 0:
        data = {'message' : 'There is no credit available in your account !', 'status' : False}
        return HttpResponse(json.dumps( data ))
    else:
        data = {'status' : True}
        return HttpResponse(json.dumps( data ))
        #return render_to_response("membership/payment_done.html", {'user_data':user_data})



def get_plan_expiry(userid,txn_id):
    try:
        payment_date = PayPalIPN.objects.filter(txn_id=txn_id).values('payment_date')
        credit_expire_date = payment_date[0]["payment_date"]+ timedelta(days = 30)
        alert_expire_date = credit_expire_date - timedelta(days = 7)
        return (credit_expire_date, alert_expire_date)
    except Exception as e:
        return HttpResponse('Something Went Wrong !')



def add_balanced_credit(previous,provided):
    return int(previous) + int(provided)



@receiver(valid_ipn_received)
def show_me_the_money(sender, **kwargs):
    ipn_obj = sender
    f=open('userupdate1.txt','w')
    if ipn_obj.payment_status == "Completed":
        try:
            paid_amount = ipn_obj.payment_gross
            check_provided_credits = Plans.objects.filter(plan_amount = int(paid_amount)).values('plan_credits')
            check_previous_credit = User.objects.filter(id = ipn_obj.custom).values('credits')
            prov_c = check_provided_credits[0]['plan_credits']
            prv_c = check_previous_credit[0]['credits']
            if not prv_c:
                prv_c = 0
            instance = Membership_transaction.objects.create(user_id = ipn_obj.custom, transaction_id = ipn_obj.txn_id, previous_credits = prv_c, provide_credits = prov_c)
            if instance:
                add_credits = add_balanced_credit(prv_c, prov_c)
                update_credit_expire, alert_date = get_plan_expiry(ipn_obj.custom,ipn_obj.txn_id)
                f.write('credit expire date->'+str(update_credit_expire)+'credit expire alert->'+str(alert_date))
                q= User.objects.filter(id=ipn_obj.custom).update(credits = int(add_credits), credit_expire = update_credit_expire,is_payment=int(1))
                payment_data={'prv_c':prv_c, 'prov_c':prov_c, 'paid_amount':paid_amount,'txn_id':ipn_obj.txn_id,'dop':ipn_obj.payment_date}
                f.write('payment_date->'+str(payment_data)+'query_data->'+str(q.query))
            else:
                pass

        except Exception as e:
            f.write('exc->'+str(e))
            f.write('exception ->'+str(traceback.format_exc()))

    else:
    	pass

#valid_ipn_received.connect(show_me_the_money)


@receiver(invalid_ipn_received)
def do_not_show_me_the_money(sender, **kwargs):
    ipn_invalid_obj = sender
    f = open('invalid_response.txt','a+')
    f.write(ipn_invalid_obj)



@login_required(login_url='/')
def membership(request):
	subscription_plan = Plans.objects.all()
	return render(request, "membership/membership.html", context={'plans_data':subscription_plan})

@csrf_exempt
def notify(request):
    valid_ipn_received.connect(show_me_the_money)
    #payment_was_successful.connect(show_me_the_money)
    # context = {}
    # print('request-->',request.POST)
    f=open("ipresponse.txt", "a+")
    f.write(json.dumps(request.POST))
    #return render(request, 'index.html')
    return HttpResponse(escape(repr(request.GET)))
    # return render_to_response("accounts/payment_notify.html", context)

@csrf_exempt
def cancel(request):
    valid_ipn_received.connect(show_me_the_money)
    context = {}
    return render_to_response("membership/payment_canceled.html", context)

@csrf_exempt
def return_view(request):
    #valid_ipn_received.connect(show_me_the_money)
    user_data = User.objects.get(id= request.user.id)
    return render_to_response("membership/payment_done.html", {'user_data':user_data})
