from django.apps import AppConfig


class MembershipConfig(AppConfig):
    name = 'membership'
