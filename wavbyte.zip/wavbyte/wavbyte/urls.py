"""wavbyte URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls.static import static
from django.contrib.auth.decorators import login_required
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from django.contrib import admin
from django.conf.urls import url, include
from django.urls import path, re_path

from accounts import views
from accounts.models import payment_decorator
from accounts.views import UploadedSong, DownloadSongList
from wavbyte import settings

urlpatterns = [
    re_path(r'^$', views.landing_page, name='landing_page'),
    re_path(r'^sample$', views.sample_page, name='sample_page'),
    re_path(r'^sample/detail/(?P<pk>[0-9]+)$', views.sample_detail, name='sample_detail'),
    re_path(r'^album/detail/(?P<pk>[0-9]+)$', views.album_detail, name='album_detail'),
    re_path(r'^allsong$', views.allsong, name='allsong'),
    re_path(r'^popular$', views.popular, name='popular'),
    re_path(r'^albumlist$', views.albumList, name='albumlist'),
    re_path(r'^play$', views.play, name='play'),
    re_path(r'^albumlike/(?P<pk>[0-9]+)$', views.like_album_song, name='like_album_song'),
    re_path(r'^albumunlike/(?P<pk>[0-9]+)$', views.unlike_album_song, name='unlike_album_song'),
    re_path(r'^like/(?P<pk>[0-9]+)$', views.like_song, name='like_song'),
    re_path(r'^unlike/(?P<pk>[0-9]+)$', views.unlike_song, name='unlike_song'),
    re_path(r'^follow/(?P<song_id>[0-9]+)/(?P<pk>[0-9]+)$', views.user_fallow, name='user_fallow'),
    re_path(r'^unfollow/(?P<song_id>[0-9]+)/(?P<pk>[0-9]+)$', views.user_unfallow, name='user_unfallow'),
    re_path(r'^searchBar$', views.searchBar, name='searchBar'),
    re_path(r'^search$', views.search_song, name='search_song'),
    re_path(r'^wallet$', views.wallet, name='wallet'),
    re_path(r'^wallet/uploads$', login_required(payment_decorator(UploadedSong.as_view())), name='all_uploaded_song'),
    re_path(r'^wallet/download$', login_required(payment_decorator(DownloadSongList.as_view())), name='all_uploaded_song'),
    re_path(r'^downloadinwallet$', views.download_in_wallet, name="download_in_wallet"),
    re_path(r'^download$', views.download, name="download"),
    re_path(r'^upload/type$', views.upload_type, name='upload_page'),
    re_path(r'^add/album$', views.add_album, name='add_album'),
    re_path(r'^upload/done/(?P<pk>[0-9]+)$', views.upload_done, name='upload_done'),
    re_path(r'^login$', views.user_login, name='user_login'),
    re_path(r'^logout$', views.user_logout),
    re_path(r'^signup$', views.user_signup),
    re_path(r'^dashboard$', views.dashboard_page, name='dashboard'),
    re_path(r'^profile$', views.profile_page, name='myprofile'),
    re_path(r'^update_profile$', views.update_profile, name='update_my_profile'),
    re_path(r'^change_password$', views.change_password, name='update_my_profile'),
    re_path(r'^upload/image$', views.update_image, name='update_my_profile'),

    re_path(r'^activate/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$', views.activate, name='activate'),
    re_path(r'^password_reset$', views.password_reset,name='password_reset'),
    re_path(r'^password_reset/done/$', views.password_reset_done,name='password_reset_done'),
    re_path(r'^reset/(?P<uidb64>[0-9A-Za-z_\-]+)/(?P<token>[0-9A-Za-z]{1,13}-[0-9A-Za-z]{1,20})/$', views.password_reset_confirm,name='password_reset_confirm'),
    re_path(r'^reset/done/$', views.password_reset_complete, name='password_reset_complete'),
    path('paypal/', include('paypal.standard.ipn.urls')),
    path('admin/', admin.site.urls),
    path('', include('membership.urls')),
]
urlpatterns += staticfiles_urlpatterns()
urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
