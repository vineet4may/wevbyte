from datetime import datetime, timedelta

from accounts.models import Follow, Song


def follow_user_notifications(request):
    to_date = datetime.now().date() + timedelta(days=1)
    from_date = datetime.now().date() - timedelta(days=1)
    follow_user_id = Follow.objects.filter(follower_id=request.user.id, is_fallow=1).values_list('following_id',flat=True)
    follow_user_song_list = Song.all_music.filter(user_id__in=follow_user_id, created__range=(from_date, to_date)).order_by('-created')
    count = follow_user_song_list.count()
    return {'objects_list':follow_user_song_list, 'total':count}